import java.util.Date;

public class AlfredQuotes {

    public String basicGreeting() {
        return "Hello, lovely to see you. How are you?";
    }

    public String guestGreeting(String name, String dayPeriod) {
        String newGreeting = String.format("Good %s, so very lovely to see you %s", dayPeriod, name);
        return newGreeting;
    } 

    public String dateAnnouncement() {
        Date date = new Date();
        return "Greetings. Today's date is " + date;
    }

    public String respondBeforeAlexis(String conversation) {
        if(conversation.indexOf("Alexis") >= 0) {
            return "Hmph. Alexis really is useless and not nearly sophisticated enough for that task.";
        }
        else if(conversation.indexOf("Alfred") >= 0) {
            return "At your service. As you wish, naturally.";
        }
        else {
            return "I'm on it!";
        }
    }

    public String dismissal(String command) {
        if(command.indexOf("Please") >= 0) {
            return "Get lost. I'm busy now.";
        }
        else {
            return "Go fuck yourself you little fucker.";
        }

    }
}