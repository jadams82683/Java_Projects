public class TestFizzBuzz {

    public static void main(String[] args) {

        FizzBuzz fizzy = new FizzBuzz();

        String testFizzBuzz = fizzy.fizzBuzz(31);
        System.out.println(testFizzBuzz);

        for(int i = 1; i <= 50; i++) {
            System.out.println(fizzy.fizzBuzz(i));
        }

        System.out.println(fizzy.fizzBuzz(25, "Antonio", "Emanuela", "Eleanor"));
    }
}
