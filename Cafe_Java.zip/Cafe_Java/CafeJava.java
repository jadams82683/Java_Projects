public class CafeJava {
    public static void main(String[] args) {
        
        String generalGreeting = "Welcome to Cafe Java, ";
        String pendingMessage = ", your order will be ready shortly";
        String readyMessage = ", your order is ready";
        String displayTotalMessage = "Your total is $";

        double mochaPrice = 3.5;
        double coffeePrice = 2.25;
        double cappuccinoPrice = 4.5;
        double espressoPrice = 3.75;

        String customer1 = "Antonio";
        String customer2 = "Emanuela";
        String customer3 = "Eleanor";
        String customer4 = "Cocoa";

        boolean isReadyOrder1 = true;
        boolean isReadyOrder2 =  false;
        boolean isReadyOrder3 = true;
        boolean isReadyOrder4 = false;

        System.out.println("Hello. " + generalGreeting + customer1 + readyMessage);
        if(isReadyOrder2) {
            System.out.println("Hello. " + generalGreeting + customer2 + ". " + readyMessage + ". " + displayTotalMessage + espressoPrice * 2);
        }
        else {
            System.out.println("Hello. " + generalGreeting + customer2  + pendingMessage);

        }

        System.out.println("Hello " + customer4 + readyMessage + ". " + displayTotalMessage + (espressoPrice - coffeePrice));

        if(isReadyOrder3) {
            System.out.println("Hello " + customer3 + readyMessage + ". " + displayTotalMessage + (cappuccinoPrice + coffeePrice));
        }
        else {
            System.out.println(pendingMessage);
        }
        
        }

    }
