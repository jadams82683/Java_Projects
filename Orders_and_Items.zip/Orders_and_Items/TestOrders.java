import java.util.ArrayList;

public class TestOrders {
    public static void main(String[] args) {

        Item item1 = new Item();
        item1.name = "Coffee";
        item1.price = 2.25;

        Item item2 = new Item();
        item2.name = "Ham Sandwich";
        item2.price = 5.50;

        Item item3 = new Item();
        item3.name = "Chocolate Chip Cookie";
        item3.price = 1.75;

        Item item4 = new Item();
        item4.name = "Salad";
        item4.price = 4.75;

        Order order1 = new Order();
        Order order2 = new Order();
        Order order3 = new Order();
        Order order4 = new Order();

        System.out.println(item4.price);

        order1.name = "Wolfgang";
        order2.name = "Ludwig";
        order3.name = "Johann";
        order4.name = "Franz";

        System.out.println(order1.name);

        order2.items.add(item1);
        order2.total += item1.price;
        order3.items.add(item3);
        order3.total += item3.price;
        order4.items.add(item2);
        order4.total += item2.price;
        order1.ready = true;
        order2.items.add(item1);
        order2.items.add(item1);
        order2.total += (item1.price * 2);
        order4.ready = true;

        System.out.println(order2.total);
        System.out.printf("Name: %s\n", order1.name);
        System.out.printf("Total: %s\n", order1.total);
        System.out.printf("Ready: %s\n", order1.ready);
        System.out.printf("Name: %s\n", order2.name);
        System.out.printf("Total: %s\n", order2.total);
        System.out.printf("Ready: %s\n", order2.ready);
        System.out.printf("Name: %s\n", order3.name);
        System.out.printf("Total: %s\n", order3.total);
        System.out.printf("Ready: %s\n", order3.ready);
        System.out.printf("Name: %s\n", order4.name);
        System.out.printf("Total: %s\n", order4.total);
        System.out.printf("Ready: %s\n", order4.ready);

    }
}
